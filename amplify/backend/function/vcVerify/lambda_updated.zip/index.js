/**
 * @type {import('@types/aws-lambda').APIGatewayProxyHandler}
  blsVerify,
  blsVerifyProof,
} from "@mattrglobal/bbs-signatures";
 */

import { blsVerify } from '@mattrglobal/bbs-signatures';

exports.handler = async (event) => {
  console.log(`EVENT: ${JSON.stringify(event)}`);

  const messages = JSON.parse(event.pathParameters.messages);
  const publicKey = Buffer.from(event.pathParameters.publicKey, 'base64'); // adjust format
  const signature = Buffer.from(event.pathParameters.signature, 'base64'); // adjust format

  const isValid = await blsVerify({ messages, publicKey, signature });

  return {
    statusCode: 200,
    //  Uncomment below to enable CORS requests
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "*"
    },
    body: JSON.stringify({ isValid }),
  };
};
