/**
 * @type {import('@types/aws-lambda').APIGatewayProxyHandler}
 */
// this is /userId
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  ScanCommand,
  PutCommand,
  GetCommand,
  DeleteCommand,
} from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});

const dynamo = DynamoDBDocumentClient.from(client);

const tableName = "verifiable-credentials-zk-application-dynamodb";

// handle retrieving and deleting user data only 
exports.handler = async (event) => {
  console.log(`EVENT: ${JSON.stringify(event)}`);
  // try {
  //   switch (event.routeKey) {
  //     case "GET /userId":
  //       body = await dynamo.send(
  //         new GetCommand({
  //           TableName: tableName,
  //           Key: {
  //             email: event.pathParameters.email,
  //           },
  //         })
  //       );
  //       body = body.Item;
  //       break;
  //     case "DELETE /userId":
  //       // handle DELETE request, not necessary for the demo
  //       console.log("DELETE request received");
  //       break;
  //     default:
  //       throw new Error(`Unsupported route: "${event.routeKey}"`);
  //   }
  // } catch (err) {
  //   statusCode = 400;
  //   body = err.message;
  // } finally {
  //   body = JSON.stringify(body);
  // }

  // const positions = event.queryStringParameters.positions.split(',').map(x => parseInt(x, 10));
  // const allMessages = event.queryStringParameters.allMessages.split(',');
  // console.log("Positions:", positions);
  // console.log("All Messages:", allMessages);

  // const pair = await generateBls12381G2KeyPair()
  // console.log("Key Pair Generated:", pair);
  return {
    statusCode: 200,
    //  Uncomment below to enable CORS requests
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "*"
    },
    // body: body,
    body: JSON.stringify({
      message: "Hello from Lambda!",
      // pair: pair
    }),
  };
};
